SELECT a.*
FROM auth_user a
WHERE a.id = $1
--
export class AuthUser {
  id: number;
  first_name: string;
  middle_name: string;
  second_name: string;
  password: string;
  role_id: number;
}

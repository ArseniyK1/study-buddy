export class CreateAuthUserDto {}
